package PacMan;

public class Point {

}
