package PacMan;

public class Fantome {

}
