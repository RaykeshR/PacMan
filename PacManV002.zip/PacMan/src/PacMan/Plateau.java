package PacMan;

public class Plateau {

}
