package PacManpackage;

public class Fantome {

}
