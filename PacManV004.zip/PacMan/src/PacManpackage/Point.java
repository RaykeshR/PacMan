package PacManpackage;

public class Point {

}
