package pacman;

public class pacman {

}
