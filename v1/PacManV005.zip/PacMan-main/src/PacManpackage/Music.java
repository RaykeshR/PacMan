package PacManpackage;

public class Music {
	//wav : /PacMan/src/Source/PacMan-Original-Theme.wav
	//mp3 : /PacMan/src/Source/PacMan Original Theme.mp3
	//TODO
}
