# PacMan
Le [
PDF](https://campus.eseo.fr/pluginfile.php/386417/mod_resource/content/2/PacMan.pdf).


N'oubliez pas de voir notre Site : [Liens vers Notre Site ]().


### III. Les fonctionnalité de Base
* 1 Niveau qui ce termine à 1000 points (100x10 <=> 100 Bonus) et affiche `“CONGRATULATIONS! YOUR LEVEL IS COMPLETE!”` (Avec Score et temps)
* 1 fantôme 👻
* contrôle par clavier ⌨ et mouvement du fantôme 👻 aléatoire
* Mort ☠ lors du contact avec le fantôme 👻 et msg :  `“GAME OVER!”`
* Pacman circulaire de couleur jaune seulement.

> [!NOTE]
> Donc map+<sub>🟡</sub>+🟡+👻 +◀️+🔼+🔽+▶️+📊+⏱️+🎲

### III. Les fonctionnalité avancé (Optionnel)


@PacMan :+1: This PR looks great - it's ready to merge! :octocat: :neckbeard: :bowtie: :shipit:



##### Ici la matrice du plateau utiliser :

<!-- ![alt text](https://github.com/[username]/[reponame]/blob/[branch]/image.jpg?raw=true) -->
>![alt text](https://github.com/RaykeshR/PacMan/blob/main/matriceDuPlateau.png)


