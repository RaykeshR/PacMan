package point;

public class point {

}
