package plateau;

public class plateau {

}
