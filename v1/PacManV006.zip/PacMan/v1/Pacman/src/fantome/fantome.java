package fantome;

public class fantome {

}
